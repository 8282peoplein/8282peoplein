from django.apps import AppConfig


class CrawledDataConfig(AppConfig):
    name = 'crawled_data'
