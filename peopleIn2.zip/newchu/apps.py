from django.apps import AppConfig


class Chu222Config(AppConfig):
    name = 'chu222'
