from django.contrib import admin

from newchu.models import Maechul

admin.site.register(Maechul)
