from django.contrib import admin
from .models import Juicy, Gongcha, Subway, Starbucks, Momstouch, Ediya, Sinjeon, Caffebene, Mrsd


admin.site.register(Juicy)
admin.site.register(Gongcha)
admin.site.register(Subway)
admin.site.register(Starbucks)
admin.site.register(Momstouch)
admin.site.register(Ediya)
admin.site.register(Sinjeon)
admin.site.register(Caffebene)
admin.site.register(Mrsd)