from django.apps import AppConfig


class ChuConfig(AppConfig):
    name = 'chu'
